package com.example.brais.musicband;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Esta actividad su interfaz va a ser el archivo xml con ese nombre, aquí se enlaza la parte
        //lógica y la parte gráfica.
    }

}
